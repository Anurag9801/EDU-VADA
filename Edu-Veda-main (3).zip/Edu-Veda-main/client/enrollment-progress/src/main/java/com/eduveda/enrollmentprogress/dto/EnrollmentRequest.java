package com.eduveda.enrollmentprogress.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EnrollmentRequest {
    private Long studentId;
    private Long courseId;
    private String status;
    private Long createdBy;
    private Long updatedBy;

    public EnrollmentRequest(Long studentId, Long courseId, String status) {
        this.studentId = studentId;
        this.courseId = courseId;
        this.status = status;
    }
}
