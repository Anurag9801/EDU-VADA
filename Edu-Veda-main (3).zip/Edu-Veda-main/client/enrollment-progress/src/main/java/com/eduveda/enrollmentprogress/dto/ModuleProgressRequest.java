package com.eduveda.enrollmentprogress.dto;

import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ModuleProgressRequest {
    private Long userId;
    private Long resourceId;
    private Long courseId;
    private Boolean completed;
    private LocalDateTime completedAt;
    private Long createdBy;
    private Long updatedBy;

    public ModuleProgressRequest(Long userId, Long resourceId, Long courseId, Boolean completed) {
        this.userId = userId;
        this.resourceId = resourceId;
        this.courseId = courseId;
        this.completed = completed;
    }
}
