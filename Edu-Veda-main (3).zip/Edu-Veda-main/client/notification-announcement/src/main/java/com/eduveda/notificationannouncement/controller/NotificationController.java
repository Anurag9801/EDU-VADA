package com.eduveda.notificationannouncement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.eduveda.notificationannouncement.dto.NotificationRequest;
import com.eduveda.notificationannouncement.entity.Notification;
import com.eduveda.notificationannouncement.service.NotificationService;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1/notifications")
@Slf4j
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @PostMapping
    public ResponseEntity<Notification> createNotification(@RequestBody NotificationRequest request) {
        Notification notification = notificationService.createNotification(request);
        log.info("Notification created with id {}", notification.getId());
        return ResponseEntity.ok(notification);
    }

    @GetMapping
    public ResponseEntity<List<Notification>> getNotifications(@RequestParam Long userId,
            @RequestParam(required = false) List<Long> enrolledCourseIds,
            @RequestParam(required = false) List<Long> instructorCourseIds) {
        List<Notification> notifications = notificationService.getNotificationsForUser(userId, enrolledCourseIds,
                instructorCourseIds);
        return ResponseEntity.ok(notifications);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteNotification(@PathVariable Long id) {
        notificationService.deleteNotification(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}/read")
    public ResponseEntity<Void> markAsRead(@PathVariable Long id) {
        notificationService.markAsRead(id);
        return ResponseEntity.noContent().build();
    }
}
