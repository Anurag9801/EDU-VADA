package com.eduveda.notificationannouncement.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eduveda.notificationannouncement.dto.AnnouncementRequest;
import com.eduveda.notificationannouncement.entity.Announcement;
import com.eduveda.notificationannouncement.repository.AnnouncementRepository;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AnnouncementService {

    @Autowired
    private AnnouncementRepository announcementRepository;

    public Announcement createAnnouncement(AnnouncementRequest request) {
        Announcement announcement = new Announcement(
                request.getTitle(),
                request.getMessage(),
                request.getCourseId(),
                request.getExpiresAt(),
                request.getCreatedBy());
        Announcement saved = announcementRepository.save(announcement);
        log.info("Announcement {} created for course {}", saved.getId(), saved.getCourseId());
        return saved;
    }

    public List<Announcement> getAnnouncementsForCourses(List<Long> courseIds) {
        List<Announcement> list = announcementRepository.findActiveAnnouncementsForCourses(courseIds,
                LocalDateTime.now());
        log.debug("Fetched {} announcements for courses {}", list.size(), courseIds);
        return list;
    }

    public List<Announcement> getAnnouncementsByCourseId(Long courseId) {
        return announcementRepository.findByCourseId(courseId);
    }

    public List<Announcement> getAllAnnouncements() {
        return announcementRepository.findAll();
    }

    public void deleteAnnouncement(Long announcementId) {
        announcementRepository.deleteById(announcementId);
        log.info("Announcement {} deleted", announcementId);
    }
}
