package com.eduveda.notificationannouncement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NotificationRequest {

    private Long userId;
    private Long relatedEntityId;
    private String relatedEntityType;
    private String title;
    private String message;
    private String type;
    private Long createdBy;
}
