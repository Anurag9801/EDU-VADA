package com.eduveda.notificationannouncement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.eduveda.notificationannouncement.dto.AnnouncementRequest;
import com.eduveda.notificationannouncement.entity.Announcement;
import com.eduveda.notificationannouncement.service.AnnouncementService;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1/announcements")
@Slf4j
public class AnnouncementController {

    @Autowired
    private AnnouncementService announcementService;

    @PostMapping
    public ResponseEntity<Announcement> createAnnouncement(@RequestBody AnnouncementRequest request) {
        Announcement announcement = announcementService.createAnnouncement(request);
        log.info("Announcement created with id {}", announcement.getId());
        return ResponseEntity.ok(announcement);
    }

    @GetMapping
    public ResponseEntity<List<Announcement>> getAnnouncements(@RequestParam(required = false) List<Long> courseIds) {
        List<Announcement> announcements;
        if (courseIds != null && !courseIds.isEmpty()) {
            announcements = announcementService.getAnnouncementsForCourses(courseIds);
        } else {
            announcements = announcementService.getAllAnnouncements();
        }
        return ResponseEntity.ok(announcements);
    }

    @GetMapping("/course/{courseId}")
    public ResponseEntity<List<Announcement>> getAnnouncementsByCourse(@PathVariable Long courseId) {
        List<Announcement> announcements = announcementService.getAnnouncementsByCourseId(courseId);
        return ResponseEntity.ok(announcements);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAnnouncement(@PathVariable Long id) {
        announcementService.deleteAnnouncement(id);
        return ResponseEntity.noContent().build();
    }
}
