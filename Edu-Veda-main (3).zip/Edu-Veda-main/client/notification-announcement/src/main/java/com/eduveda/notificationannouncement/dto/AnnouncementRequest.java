package com.eduveda.notificationannouncement.dto;

import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AnnouncementRequest {

    private String title;
    private String message;
    private Long courseId;
    private LocalDateTime expiresAt;
    private Long createdBy;
}
