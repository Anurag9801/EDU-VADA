package com.eduveda.assessmentmanagement.dto;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AssessmentRequest {
    private Long courseId;
    private String title;
    private String description;
    private List<Question> questions;
    private Long createdBy;
    private Long updatedBy;

    // Inner class for Question
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Question {
        private String text;
        private List<String> options;
        private String answer;
    }
}
