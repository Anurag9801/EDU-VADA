package com.eduveda.assessmentmanagement.entity;

import java.time.LocalDateTime;
import java.util.List;

import com.eduveda.assessmentmanagement.dto.AssessmentRequest;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "assessments")
@Getter
@Setter
@NoArgsConstructor
public class Assessment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "course_id", nullable = false)
    private Long courseId;

    @Column(name = "module_id")
    private Long moduleId;

    @Column(name = "type", nullable = false)
    private String type = "quiz";

    @Column(name = "title", nullable = false)
    private String title;

    @Column(name = "description")
    private String description;

    @Lob
    @Column(name = "questions_json", columnDefinition = "TEXT")
    private String questionsJson;

    @Lob
    @Column(name = "correct_answers_json", columnDefinition = "TEXT")
    private String correctAnswersJson;

    @Column(name = "max_score")
    private Integer maxScore;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "version", nullable = false)
    private Integer version = 1;

    // Transient field for deserialized questions
    private transient List<AssessmentRequest.Question> questions;

    // Constructors
    public Assessment(Long courseId, String title, String description, String questionsJson, String correctAnswersJson,
            Integer maxScore, Long createdBy) {
        this.courseId = courseId;
        this.title = title;
        this.description = description;
        this.questionsJson = questionsJson;
        this.correctAnswersJson = correctAnswersJson;
        this.maxScore = maxScore;
        this.createdBy = createdBy;
        this.updatedBy = createdBy;
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    public void preUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
