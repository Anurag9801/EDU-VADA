package com.eduveda.usermanagement.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import com.eduveda.usermanagement.dto.DeleteUserRequest;
import com.eduveda.usermanagement.dto.SignupRequest;
import com.eduveda.usermanagement.entity.User;
import com.eduveda.usermanagement.entity.UserRole;
import com.eduveda.usermanagement.exception.ResourceNotFoundException;
import com.eduveda.usermanagement.repository.UserRepository;
import com.eduveda.usermanagement.service.UserRoleService;
import com.eduveda.usermanagement.service.UserService;
import lombok.extern.slf4j.Slf4j;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/users")
@Slf4j
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private UserRoleService userRoleService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserRepository userRepository;

    @GetMapping
    public ResponseEntity<?> getUsers(@RequestParam(required = false) String email) {
        if (email != null) {
            Optional<User> user = userService.findByEmail(email);
            return ResponseEntity.ok(user.map(List::of).orElseGet(List::of));
        }
        return ResponseEntity.ok(userService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getUserById(@PathVariable Long id) {
        Optional<User> user = userService.findById(id);
        if (user.isPresent()) {
            return ResponseEntity.ok(user.get());
        } else {
            throw new ResourceNotFoundException("User not found");
        }
    }

    @PostMapping
    public ResponseEntity<?> createUser(@Valid @RequestBody SignupRequest signupRequest) {
        String name = signupRequest.getName();
        String email = signupRequest.getEmail();
        String password = signupRequest.getPassword();
        String role = signupRequest.getRole();

        // Check if user already exists
        if (userService.findByEmail(email).isPresent()) {
            throw new IllegalArgumentException("User already exists. Please login.");
        }

        // Create user
        User savedUser = userService.createUser(email, password, name, email); // username as email
        // Assign role based on the role field
        String roleName = role.toLowerCase();
        Long roleId = roleName.equals("student") ? 1L : 2L;
        UserRole userRole = new UserRole(savedUser.getId(), roleId, roleName);
        userRoleService.save(userRole);
        return ResponseEntity.ok(savedUser);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateUser(@PathVariable Long id, @RequestBody User updateUser) {
        try {
            Optional<User> existing = userService.findById(id);
            if (!existing.isPresent()) {
                throw new ResourceNotFoundException("User not found");
            }
            User user = existing.get();
            user.setName(updateUser.getName());
            user.setEmail(updateUser.getEmail());
            user.setBio(updateUser.getBio());
            if (updateUser.getPasswordHash() != null && !updateUser.getPasswordHash().isEmpty()) {
                user.setPasswordHash(passwordEncoder.encode(updateUser.getPasswordHash()));
            }
            User saved = userRepository.save(user);
            log.info("User {} updated successfully", id);
            return ResponseEntity.ok(saved);
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error updating user {}: {}", id, e.getMessage());
            throw new RuntimeException(e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable Long id, @Valid @RequestBody DeleteUserRequest deleteRequest) {
        try {
            Optional<User> userOpt = userService.findById(id);
            if (!userOpt.isPresent()) {
                throw new ResourceNotFoundException("User not found");
            }
            User user = userOpt.get();
            if (!userService.checkPassword(user, deleteRequest.getPassword())) {
                throw new SecurityException("Incorrect password");
            }
            userService.deleteUser(id);
            log.info("User {} deleted successfully", id);
            return ResponseEntity.ok("User deleted successfully");
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error deleting user {}: {}", id, e.getMessage());
            throw new RuntimeException(e.getMessage());
        }
    }
}
