package com.eduveda.coursemanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CourseRequest {
    private String title;
    private String description;
    private Double price;
    private String image;
    private Double rating;
    private String instructor;
    private Long instructorId;
    private Long createdBy;
    private Long updatedBy;
}
