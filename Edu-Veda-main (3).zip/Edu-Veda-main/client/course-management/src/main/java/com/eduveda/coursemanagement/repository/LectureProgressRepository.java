package com.eduveda.coursemanagement.repository;
import com.eduveda.coursemanagement.entity.LectureProgress;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;
@Repository
public interface LectureProgressRepository extends JpaRepository<LectureProgress, Long> {
    Optional<LectureProgress> findByUserIdAndLectureId(Long userId, Long lectureId);
    List<LectureProgress> findByUserId(Long userId);
}