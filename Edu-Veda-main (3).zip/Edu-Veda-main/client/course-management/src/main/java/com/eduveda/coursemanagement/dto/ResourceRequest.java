package com.eduveda.coursemanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResourceRequest {
    private String title;
    private String duration;
    private String youtubeLink;
    private Long createdBy;
    private Long updatedBy;
}
