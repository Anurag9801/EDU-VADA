package com.eduveda.coursemanagement.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.eduveda.coursemanagement.dto.CourseRequest;
import com.eduveda.coursemanagement.dto.ResourceRequest;
import com.eduveda.coursemanagement.entity.Course;
import com.eduveda.coursemanagement.entity.Resource;
import com.eduveda.coursemanagement.service.CourseService;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1/courses")
@Slf4j
public class CourseController {

    @Autowired
    private CourseService courseService;

    @GetMapping
    public ResponseEntity<List<Course>> getAllCourses() {
        List<Course> courses = courseService.getAllCourses();
        return ResponseEntity.ok(courses);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Course> getCourseById(@PathVariable Long id) {
        Optional<Course> course = courseService.getCourseById(id);
        return course.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/instructor/{instructorId}")
    public ResponseEntity<List<Course>> getCoursesByInstructorId(@PathVariable Long instructorId) {
        List<Course> courses = courseService.getCoursesByInstructorId(instructorId);
        return ResponseEntity.ok(courses);
    }

    @PostMapping
    public ResponseEntity<Course> createCourse(@RequestBody CourseRequest courseRequest) {
        Course course = new Course(
                courseRequest.getTitle(),
                courseRequest.getDescription(),
                courseRequest.getPrice(),
                courseRequest.getImage(),
                courseRequest.getRating(),
                courseRequest.getInstructor(),
                courseRequest.getInstructorId());
        course.setCreatedBy(courseRequest.getCreatedBy());
        course.setUpdatedBy(courseRequest.getUpdatedBy());
        Course savedCourse = courseService.createCourse(course);
        log.info("Course {} created by instructor {}", savedCourse.getId(), savedCourse.getInstructorId());
        return ResponseEntity.ok(savedCourse);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Course> updateCourse(@PathVariable Long id, @RequestBody CourseRequest courseRequest) {
        Course courseDetails = new Course(
                courseRequest.getTitle(),
                courseRequest.getDescription(),
                courseRequest.getPrice(),
                courseRequest.getImage(),
                courseRequest.getRating(),
                courseRequest.getInstructor(),
                courseRequest.getInstructorId());
        courseDetails.setUpdatedBy(courseRequest.getUpdatedBy());
        Course updatedCourse = courseService.updateCourse(id, courseDetails);
        return updatedCourse != null ? ResponseEntity.ok(updatedCourse) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCourse(@PathVariable Long id) {
        courseService.deleteCourse(id);
        log.info("Course {} deleted", id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{courseId}/resources")
    public ResponseEntity<List<Resource>> getResourcesByCourseId(@PathVariable Long courseId) {
        List<Resource> resources = courseService.getResourcesByCourseId(courseId);
        return ResponseEntity.ok(resources);
    }

    @PostMapping("/{courseId}/resources")
    public ResponseEntity<Resource> createResource(@PathVariable Long courseId,
            @RequestBody ResourceRequest resourceRequest) {
        String youtubeId = courseService.extractYouTubeId(resourceRequest.getYoutubeLink());
        if (youtubeId == null) {
            return ResponseEntity.badRequest().build();
        }
        Resource resource = new Resource(
                courseId,
                resourceRequest.getTitle(),
                resourceRequest.getDuration(),
                youtubeId);
        resource.setCreatedBy(resourceRequest.getCreatedBy());
        resource.setUpdatedBy(resourceRequest.getUpdatedBy());
        Resource savedResource = courseService.createResource(resource);
        log.info("Resource {} created in course {}", savedResource.getId(), courseId);
        return ResponseEntity.ok(savedResource);
    }

    @PutMapping("/resources/{id}")
    public ResponseEntity<Resource> updateResource(@PathVariable Long id,
            @RequestBody ResourceRequest resourceRequest) {
        String youtubeId = courseService.extractYouTubeId(resourceRequest.getYoutubeLink());
        if (youtubeId == null) {
            return ResponseEntity.badRequest().build();
        }
        Resource resourceDetails = new Resource();
        resourceDetails.setTitle(resourceRequest.getTitle());
        resourceDetails.setDuration(resourceRequest.getDuration());
        resourceDetails.setYoutubeId(youtubeId);
        resourceDetails.setUpdatedBy(resourceRequest.getUpdatedBy());
        Resource updatedResource = courseService.updateResource(id, resourceDetails);
        return updatedResource != null ? ResponseEntity.ok(updatedResource) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/resources/{id}")
    public ResponseEntity<Void> deleteResource(@PathVariable Long id) {
        courseService.deleteResource(id);
        log.info("Resource {} deleted", id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{courseId}/resources")
    public ResponseEntity<Void> updateResources(@PathVariable Long courseId,
            @RequestBody List<ResourceRequest> resourceRequests) {
        Optional<Course> existingCourse = courseService.getCourseById(courseId);
        if (existingCourse.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        if (!resourceRequests.isEmpty()
                && !existingCourse.get().getInstructorId().equals(resourceRequests.get(0).getCreatedBy())) {
            return ResponseEntity.status(403).build();
        }

        courseService.updateResourcesAndDeleteCourseIfEmpty(courseId, resourceRequests);
        log.info("Course {} resources updated", courseId);
        return ResponseEntity.ok().build();
    }
}
