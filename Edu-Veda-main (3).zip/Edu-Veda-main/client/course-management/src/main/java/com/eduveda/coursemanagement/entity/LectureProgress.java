package com.eduveda.coursemanagement.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "lecture_progress")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class LectureProgress {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long userId;
    private Long lectureId;
    private boolean completed;

    public LectureProgress(Long userId, Long lectureId, boolean completed) {
        this.userId = userId;
        this.lectureId = lectureId;
        this.completed = completed;
    }

    @Override
    public String toString() {
        return "LectureProgress{" +
                "id=" + id +
                ", userId=" + userId +
                ", lectureId=" + lectureId +
                ", completed=" + completed +
                '}';
    }
}
