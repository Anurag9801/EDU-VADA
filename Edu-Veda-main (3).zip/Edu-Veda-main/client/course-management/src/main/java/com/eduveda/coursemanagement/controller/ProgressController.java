package com.eduveda.coursemanagement.controller;

import com.eduveda.coursemanagement.entity.LectureProgress;
import com.eduveda.coursemanagement.repository.LectureProgressRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1/progress")
@Slf4j
public class ProgressController {
    @Autowired
    private LectureProgressRepository progressRepo;

    // -------------------------------
    // MARK LECTURE AS COMPLETE
    // -------------------------------
    @PostMapping("/complete")
    public ResponseEntity<?> markLectureCompleted(@RequestBody LectureProgress request) {
        Optional<LectureProgress> existing = progressRepo.findByUserIdAndLectureId(request.getUserId(),
                request.getLectureId());
        LectureProgress progress = existing.orElse(new LectureProgress());
        progress.setUserId(request.getUserId());
        progress.setLectureId(request.getLectureId());
        progress.setCompleted(true);
        progressRepo.save(progress);
        log.info("Lecture {} marked completed for user {}", request.getLectureId(), request.getUserId());
        return ResponseEntity.ok("Lecture marked completed");
    }

    // -------------------------------
    // GET ALL COMPLETED LECTURES FOR USER
    // -------------------------------
    @GetMapping("/{userId}")
    public ResponseEntity<List<LectureProgress>> getUserProgress(@PathVariable Long userId) {
        List<LectureProgress> progressList = progressRepo.findByUserId(userId);
        return ResponseEntity.ok(progressList);
    }
}