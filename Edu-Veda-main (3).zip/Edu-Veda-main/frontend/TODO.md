# TODO: Protect Necessary Routes

- [x] Wrap /course-player/:courseId with ProtectedRoute for Students
- [x] Wrap /enroll with ProtectedRoute for Students
- [x] Wrap /notifications with ProtectedRoute for logged-in users
